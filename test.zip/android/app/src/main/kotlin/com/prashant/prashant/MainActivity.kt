package com.prashant.prashant

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
